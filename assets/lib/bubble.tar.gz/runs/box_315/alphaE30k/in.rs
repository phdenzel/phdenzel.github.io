#########################################################
# 3d superheated Lennard-Jones liquid

variable	x index 1
variable	y index 1
variable	z index 1

variable	xx equal 170*$x
variable	yy equal 170*$y
variable	zz equal 170*$z

units		lj
atom_style	atomic

# Wang et al. 2009: rho=0.580, P=0.026, T=0.855
# for L=323.5584 sigma
#lattice		fcc 0.57923664202026

#lattice		fcc 0.58

#region		box block 0 ${xx} 0 ${yy} 0 ${zz}

region		cylreg cylinder x 162 162 2 0.0 324.0
#		length: 324.0

read_restart	/home/ics/phdenzel/bubble/runs/box_315/rs/rs.150000

#create_box	1 box
#create_atoms	1 box
#mass		1 1.0

#velocity	all create 0.95 227287 loop local dist gaussian

pair_style	lj/sf 2.5
pair_coeff	1 1 1.0 1.0 2.5
timestep	0.0025

neighbor	0.3 bin
neigh_modify	delay 0 every 20 check no

thermo_style    custom step temp epair etotal pe ke press
thermo		1000

#########################################################
# run for a bit under normal, stable liquid conditions

#fix		2 all temp/rescale 1 0.95 0.95 0.0 1.0
fix		1 all nve
#run		10000

#########################################################
# superheat quickly

#unfix 		2
#fix		2 all temp/rescale 1 0.95 0.855 0.0 1.0
#run		15000

#########################################################
# stabilize at new temperature for a bit

#unfix		2
#fix		2 all temp/rescale 1 0.855 0.855 0.0 1.0
#run		15000

#########################################################
# turn off temperature fixing and run as NVE

#unfix		2
compute		ekin all ke/atom
#restart		50000 rs

fix		5 all ave/spatial 1 1 1000 x lower 2.9999999323923 y lower 2.9999999323923 z lower 2.9999999323923 file n1p.hist ave one units box
fix		6 all ave/spatial 1 1 5002 x lower 5.9999998647846 y lower 5.9999998647846 z lower 5.9999998647846 c_ekin file tp.hist ave one units box

#run		100000

#########################################################
# heat spike - deposit energy in cylindrical region while running as NVE

group		wimp region cylreg
velocity	wimp scale 9.4056627 loop local dist gaussian

#########################################################

run		500000
