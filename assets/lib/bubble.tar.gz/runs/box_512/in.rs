# 3d superheated Lennard-Jones liquid

variable	x index 1
variable	y index 1
variable	z index 1

variable	xx equal 512*$x
variable	yy equal 512*$y
variable	zz equal 512*$z

units		lj
atom_style	atomic

# Wang et al. 2009: rho=0.580, P=0.026, T=0.855
# for L=975sgima: lattice		  fcc 0.57923664202026

region		cylreg cylinder x 256.0 256.0 8.0 246.0 266.0

read_restart	/home/ics/phdenzel/bubble/runs/wang09/rs.600000

pair_style	lj/sf 2.5
pair_coeff	1 1 1.0 1.0 2.5
timestep	0.0025

neighbor	0.3 bin
neigh_modify	delay 0 every 20 check no

thermo_style    custom step temp epair etotal pe ke press
thermo		1000
fix		1 all nve

#########################################################
# heat spike - deposit energy in cylindrical region while running as NVE

group		wimp region cylreg
velocity	wimp scale 2.0 loop local dist gaussian

#########################################################

compute	   	ekin all ke/atom

fix             5 all ave/spatial 1 1 1000 x lower 3.0 y lower 3.0 z lower 3.0 file n1p.hist ave one units box
fix             6 all ave/spatial 1 1 5002 x lower 6.0 y lower 6.0 z lower 6.0 c_ekin file tp.hist ave one units box

run		100000
