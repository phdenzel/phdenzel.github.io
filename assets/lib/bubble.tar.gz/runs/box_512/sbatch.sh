#!/bin/bash
#SBATCH --ntasks=256 --tasks-per-node=16 --cpus-per-task=1 --exclusive
#SBATCH -J heatspike --time=24:00:00
#export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK

srun home/ics/phdenzel/bubble/bubble_bin/lmp_linux -sf omp < in.rs > out.p.txt
