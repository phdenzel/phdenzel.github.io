/* plotcells.cpp
 * 
 * Plots cells in a simple projection
 *
 * from stdin: 	ascii file with cells from LAMMPS.
 *	
 * Output: images
 *  
 * Algorithm:
 *
 *
 * Compile with:
 * g++ plotcells.cpp -o plotcells  -L/home/ics/diemand/lib/pngwriter-0.5.4/src/ -L/home/ics/diemand/lib/ -lz -lpng -lpngwriter -DNO_FREETYPE
 *
 */
#include </home/ics/phdenzel/local/pngwriter-0.5.4/src/pngwriter.h>
#include <algorithm>
#include <math.h>
#include <string>
#include <list>
#include <fstream>
#include <iostream>

#include <stdio.h>
#include <string.h>
using namespace std;

int compare(const void * a, const void * b){
  return ( *(int*)a - *(int*)b ); 
}

int np;
int np2,np3,np3b;


// converts an id in [0,..,np3-1] to z coordinate in [0,..,L-1]
int zCoord(int id){
  int z =-1;
  if(id >np3|| id < 1) return -1;
  while(id >= 0){
	id -= np2;
	z++;
  }
  return z;
}
// converts an id in [0,..,np3-1] to y coordinate in [0,..,L-1]
int yCoord(int id){
  int y =-1;
  if(id >np3-1 || id < 0) return -1;
  while(id >= np2){
	id -= np2;
  }
  while(id >= 0){
	id -= np;
	y++;
  }
  return y;
}

// converts an id in [0,..,np3-1] to x coordinate in [0,..,L-1]
int xCoord(int id){
 
  if(id >np3-1 || id < 0) return -1;
  while(id >= np2){
	id -= np2;
  }
  while(id >= np){
	id -= np;
  }
  return id;
}

void coords(int id,int pos[3]){

  pos[0]=xCoord(id);
  pos[1]=yCoord(id);
  pos[2]=zCoord(id);

  return ;
}

// converts (x,y,z) coordinates to index (0, .. , np3-1)
int getId(int x, int y, int z){
    int id;
	// respect periodic boundaries:
	while(x<0) x=x+np;
	while(x>=np) x=x-np;
	while(y<0) y=y+np;
	while(y>=np) y=y-np;
	while(z<0) z=z+np;
	while(z>=np) z=z-np;
	id = x+ np*y + np2*z ;
	return id;
}

int main(int argc, char **argv){
  int size, amount;
  char head[500];
  char filename[50];
  int cid,i,j,timestep;
  int f,k,w,nr,nexttimestep;
  double c;
  
  w = 50; // optional parameter: boosts the number of empty cells: 
  // e.g. w=50 means that the color scale saturates if 1/50 of all cells in a column are empty.
  f = 0; // optional parameter: ignores this nubmer of empty cells: 
  // e.g. f=5 means that with up to 5 empty cells in a column the color remains unchanged.
  k=1;
  while (k < argc) {
    if (!strcmp(argv[k],"-w")) {
      ++k;
      w = atoi(argv[k]);
      ++k;
    } else if (!strcmp(argv[k],"-f")) {
      ++k;
      f = atoi(argv[k]);
      ++k;
    }
  }
  // ignore the 3 header lines
  cin.getline(head, 500);
  cin.getline(head, 500);
  cin.getline(head, 500);

  cin >> timestep; timestep *= -1;
  cin >> np3;
  np = round(pow(np3,0.3333333));
  
  np2 = np * np;
  np3b = np2 * np;
  
  if(np3 != np3b){
    cerr << "ERROR: np3 = " << np3 << " differs form np3b = "<< np3b <<"\n";
    exit(-1);   
  }
  int *image = new int[np2];
  nr = 0;
  while( cin.good() ){
    for(i=0;i<np2;i++)image[i] = 0;
    cid = 1;
    nr++;
    // use natural numbers to label images:
    //sprintf(filename,"test%d.png",nr);
    // or use timestep to label images: 
    sprintf(filename,"test%d.png",timestep/1000);
    pngwriter png(np,np,10,filename);
    
    while(cid >= 0 && cin.good() ){
      cin >> cid;
      if(cid>0 && cin.good()){
	//c = zCoord(cid);
	//c /= np;
	//png.plot(1+xCoord(cid),1+yCoord(cid),0.0, c, 1.0);
	//image[xCoord(cid)+np*yCoord(cid)] = image[xCoord(cid)+np*yCoord(cid)]+1;   // XY
	//image[xCoord(cid)+np*zCoord(cid)] = image[xCoord(cid)+np*zCoord(cid)]+1;   // XZ
	image[yCoord(cid)+np*zCoord(cid)] = image[yCoord(cid)+np*zCoord(cid)]+1;   // YZ
      }
    }
    if(cid < 0){
      cin >> np3b;
      if(np3 != np3b){
	cerr << "ERROR: np3 = " << np3 << " differs form np3b = "<< np3b <<"\n";
	exit(-1);   
      }   
      nexttimestep = -cid;      
    }
    
    for(i=0;i<np2;i++){
      c = w*(image[i]-f);
      c /= np;
      if(c < 0.0)c =0.0;
      else if(c > 1.0) c =1.0;
      png.plot(1+xCoord(i),1+yCoord(i),c,c,1.0);
    } 
     
    cerr << " timestep = " << timestep << "\n";
    png.close();
    timestep = nexttimestep;    
  }
}




































