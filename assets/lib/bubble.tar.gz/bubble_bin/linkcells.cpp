/* linkcells.cpp
 * 
 * Links neighbouring cells together and writes out the distribution of group sizes
 *
 * from stdin: 	ascii file with cells from LAMMPS.
 *	
 * Output: 
 *	ascii files containing size distribution for each timestep
 *  
 * Algorithm:
 *
 */
#include <algorithm>
#include <math.h>
#include <string>
#include <list>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <string.h>
using namespace std;

int compare(const void * a, const void * b){
  return ( *(int*)a - *(int*)b ); 
}

int np;
int np2,np3,np3b;


// converts an id in [0,..,np3-1] to z coordinate in [0,..,L-1]
int zCoord(int id){
  int z =-1;
  if(id >np3|| id < 1) return -1;
  while(id >= 0){
	id -= np2;
	z++;
  }
  return z;
}
// converts an id in [0,..,np3-1] to y coordinate in [0,..,L-1]
int yCoord(int id){
  int y =-1;
  if(id >np3-1 || id < 0) return -1;
  while(id >= np2){
	id -= np2;
  }
  while(id >= 0){
	id -= np;
	y++;
  }
  return y;
}

// converts an id in [0,..,np3-1] to x coordinate in [0,..,L-1]
int xCoord(int id){
 
  if(id >np3-1 || id < 0) return -1;
  while(id >= np2){
	id -= np2;
  }
  while(id >= np){
	id -= np;
  }
  return id;
}

void coords(int id,int pos[3]){

  pos[0]=xCoord(id);
  pos[1]=yCoord(id);
  pos[2]=zCoord(id);

  return ;
}

// converts (x,y,z) coordinates to index (0, .. , np3-1)
int getId(int x, int y, int z){
    int id;
	// respect periodic boundaries:
	while(x<0) x=x+np;
	while(x>=np) x=x-np;
	while(y<0) y=y+np;
	while(y>=np) y=y-np;
	while(z<0) z=z+np;
	while(z>=np) z=z-np;
	id = x+ np*y + np2*z ;
	return id;
}

int main(int argc, char **argv){
  const int maxncells = 1000000;
  int groups[maxncells],id[maxncells],grid[maxncells];
  int size, amount;
  char head[500];
  int k,ncells,cid,i,j,timestep,cand;
  int icrit,nexttimestep;
  int x,y,z,xi,yi,zi, cnt;
  int xcom,ycom,zcom;
  int *cube;
  bool updates;

  icrit = 0; // optional parameter: if set, coords of groups > icrit are written to stderr
  k=1;
  while (k < argc) {
    if (!strcmp(argv[k],"-icrit")) {
      ++k;
      icrit = atoi(argv[k]);
      ++k;
    }
  }
  if(icrit)cerr << "# Center-of-mass positions of all large clusters at each time-step\n";
  if(icrit)cerr << "# coordinates are given in cell counts. Range: 0, .. , nCells-1.\n";
  if(icrit)cerr << "# Timestep nCell1 nCells2 nCells3  nCells-total\n";
  if(icrit)cerr << "# id iCell1 iCell2 iCell3 group-size \n";
  // NOTE: my (x,y,z) coordinates correspond to the order (3,2,1).

  // ignore the 3 header lines
  cin.getline(head, 500);
  cin.getline(head, 500);
  cin.getline(head, 500);

  cin >> timestep; timestep *= -1;
  cin >> np3;
  np = round(pow(np3,0.3333333));
  
  np2 = np * np;
  np3b = np2 * np;
  
  if(np3 != np3b){
    cerr << "ERROR: np3 = " << np3 << " differs form np3b = "<< np3b <<"\n";
    exit(-1);   
  }
  cube = new int[np3];
  
  while( cin.good() ){
    ncells = 0;
    cid = 1;
    for(i=0;i<np3;i++)
      cube[i] = -1;

    while(cid >= 0 && cin.good() ){
      cin >> cid;
      id[ncells] = cid;
      // grid[ncells] = cid;
      if(cid>=0)cube[cid] = cid;
      ncells++;
    }
    if(cid < 0){
      cin >> np3b;
      if(np3 != np3b){
	cerr << "ERROR: np3 = " << np3 << " differs form np3b = "<< np3b <<"\n";
	exit(-1);   
      }   
      nexttimestep = -cid;      

    }
    ncells -= 1;

    if(icrit)cerr <<  timestep <<" "<< np << " "<< np <<" "<< np <<" "<< np3<< "\n";
    //cerr << " id[0] = " << id[0] << "\n";
    //cerr << " id[ncells-1] = " << id[ncells-1] << "\n \n";

    updates = true;
    while(updates){
      updates = false;
      for(i=0;i<ncells;i++){
	x = xCoord(id[i]);
	y = yCoord(id[i]);
	z = zCoord(id[i]);
	for(zi = z+1 ;zi >= z-1 ;zi--){
	  for(yi = y+1 ;yi >= y-1 ;yi--){
	    for(xi = x+1 ;xi >= x-1 ;xi--){ 
	      // if the candidates is in a group and his group id is lower than the current groupId:
	      // then set current groupId = cand group id.
	      cand = getId(xi,yi,zi);
	      if( cube[cand] >=0 && cube[cand] < cube[id[i]]){
		//cerr << "i="<<i <<", grid[i] = " << cube[id[i]] << ",  cand = " << cand
		//     <<" grid of cand = "<< cube[cand]<<" \n";
		cube[id[i]] = cube[cand];
		updates = true;
	      }
	    }
	  }
	}
	grid[i] = cube[id[i]];
      }
    }
    qsort(grid,ncells,sizeof(int),compare);
    size = 1;
    // determine group sizes:
    for(i=1;i<ncells;i++){
      groups[i] = 0;
    }
    for(i=1;i<ncells;i++){
      if(grid[i] == grid[i-1])
	size++;
      else{
	if(size >= 1) groups[i-1] = size;
	size = 1;
      }
    }
    groups[i-1] = size;    
    
    for(i=1;i<ncells;i++){
      size = groups[i];
      if(icrit and size >= icrit){
	// calculate center of mass of this large cluster:
	xcom = 0.0;
	ycom = 0.0;
	zcom = 0.0;
	cnt = 0;
	for(j=0;j<np3;j++){
	  if( cube[j] == grid[i]){
	    x = xCoord(j); y = yCoord(j); z = zCoord(j); 
	    if(cnt){ // take care of periodic boundaries:
	      if( xcom/cnt - x > np/2 ) x += np;
	      else if( xcom/cnt - x < -np/2 ) x -= np;
	      if( ycom/cnt - y > np/2 ) y += np;
	      else if( ycom/cnt - y < -np/2 ) y -= np;
	      if( zcom/cnt - z > np/2 ) z += np;
	      else if( zcom/cnt - z < -np/2 ) z -= np;
	    }
	    xcom += x; ycom += y; zcom += z;
	    cnt++;
	  }
	}
	x = xcom/cnt; y = ycom/cnt; z = zcom/cnt;
	if(x < 0) x += np; else if(x >= np) x -= np;
	if(y < 0) y += np; else if(y >= np) y -= np;
	if(z < 0) z += np; else if(z >= np) z -= np;
	if(cnt != size ) cerr << "count and size mismatch: cnt = "<< cnt << "\n";
	cerr <<"  "<< grid[i] <<" " << z <<" " << y <<" " << x <<" " << size << "\n";
      }
    }
    
    
    fprintf(stdout, "%d %d\n", timestep, np3);  
    qsort(groups, ncells, sizeof(int), compare);
    amount = 1;
    for(i = ncells-2; i>=0; i--)
      {
	if (groups[i] == 0)
	  break;
	if (groups[i] == groups[i+1])
	  amount++;
	else {
	  fprintf(stdout, "%d %d\n", groups[i+1], amount);
	  amount = 1;
	}
      }
    fprintf(stdout, "%d %d\n", groups[i+1], amount);
    fflush(stdout);
    timestep = nexttimestep;    
  }
}
